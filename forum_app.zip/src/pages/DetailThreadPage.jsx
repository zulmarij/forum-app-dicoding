import React from 'react';
import DetailThread from '../components/DetailThread';

export default function DetailThreadPage() {
  return (
    <section>
      <DetailThread />
    </section>
  );
}
