import { hideLoading, showLoading } from 'react-redux-loading-bar';
import api from '../../../utils/api';
import { getAllThreadsActionCreator } from '../threads/action';
import { getAllUsersActionCreator } from '../users/action';

function asyncPopulateUsersAndThreads() {
  return async (dispatch) => {
    dispatch(showLoading());
    const { status: statusUsers, data: { users } } = await api.getAllUsers();
    const { status: statusThreads, message, data: { threads } } = await api.getAllThreads();
    if (statusThreads === 'success') dispatch(getAllThreadsActionCreator(threads));
    if (statusUsers === 'success') dispatch(getAllUsersActionCreator(users));
    dispatch(hideLoading());

    return { status: statusThreads, message };
  };
}

// eslint-disable-next-line import/prefer-default-export
export { asyncPopulateUsersAndThreads };
