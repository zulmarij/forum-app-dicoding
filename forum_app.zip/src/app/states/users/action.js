import { hideLoading, showLoading } from 'react-redux-loading-bar';
import api from '../../../utils/api';

const ActionType = {
  REGISTER_USER: 'REGISTER',
  GET_ALL_USERS: 'GET_ALL_USERS',
};

function registerUserActionCreator(user) {
  return {
    type: ActionType.REGISTER_USER,
    payload: {
      user,
    },
  };
}

function getAllUsersActionCreator(users) {
  return {
    type: ActionType.GET_ALL_USERS,
    payload: {
      users,
    },
  };
}

function asyncRegisterUser({ name, email, password }) {
  return async (dispatch) => {
    dispatch(showLoading());
    const { status, message, data: { user } } = await api.registerUser({ name, email, password });
    if (status === 'success') dispatch(registerUserActionCreator(user));
    dispatch(hideLoading());

    return { status, message };
  };
}

export {
  ActionType,
  registerUserActionCreator,
  getAllUsersActionCreator,
  asyncRegisterUser,
};
