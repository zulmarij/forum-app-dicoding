import { hideLoading, showLoading } from 'react-redux-loading-bar';
import api from '../../../utils/api';

const ActionType = {
  LOGIN: 'LOGIN',
  LOGOUT: 'LOGOUT',
};

function loginActionCreator(authUser) {
  return {
    type: ActionType.LOGIN,
    payload: {
      authUser,
    },
  };
}

function logoutActionCreator() {
  return {
    type: ActionType.LOGOUT,
  };
}

function asyncLogin({ email, password }) {
  return async (dispatch) => {
    dispatch(showLoading());
    const { status, message, data: { token } } = await api.login({ email, password });
    if (status === 'success') {
      api.putAccessToken(token);
      const { data: { user } } = await api.getOwnProfile();
      dispatch(loginActionCreator(user));
    }
    dispatch(hideLoading());

    return { status, message };
  };
}

function asyncLogout() {
  return async (dispatch) => {
    dispatch(showLoading());
    dispatch(logoutActionCreator());
    api.putAccessToken('');
    dispatch(hideLoading());

    return { status: 'success', message: 'ok' };
  };
}

export {
  ActionType,
  loginActionCreator,
  logoutActionCreator,
  asyncLogin,
  asyncLogout,
};
